package com.gumtree.addressbook;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.gumtree.addressbook.AddressBookList;
import com.gumtree.addressbook.ReadFile;
import com.gumtree.addressbook.model.AddressBook;
import com.gumtree.addressbook.model.Gender;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:/com/gumtree/addressbook/AddressBookITTest-context.xml")
public class ReadFileITTest {
	
	@Autowired
	ReadFile readFile;
	
	@Test
	public void testAddressBook()throws Exception{
		AddressBookList<AddressBook> addressBookList = readFile.loadFile();
		assertEquals(5,addressBookList.size());
		assertEquals(3,addressBookList.getMaleCount());
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/y");
		assertEquals(new AddressBook("Wes Jackson",Gender.Male,dateFormat.parse("14/08/74")),  addressBookList.getMaxAge());
	}

}
