package com.gumtree.addressbook;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.Test;

import com.gumtree.addressbook.model.AddressBook;
import com.gumtree.addressbook.model.Gender;
import static org.junit.Assert.*;

public class AddressBookListTest {
	
	@Test
	public void testMaleCount()throws Exception{
		AddressBookList addressBooks = sampleData();
		assertEquals(3,addressBooks.size());
		assertEquals(2,addressBooks.getMaleCount());
	}

	private AddressBookList<AddressBook> sampleData() throws ParseException {
		AddressBookList<AddressBook> addressBooks = new AddressBookList<AddressBook>();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/y");
		
		AddressBook addressBook= new AddressBook("Paul Robinson", Gender.Male, dateFormat.parse("15/01/85"));
		
		addressBooks.add(addressBook);
		addressBook= new AddressBook("Bill McKnight", Gender.Male, dateFormat.parse("16/03/77"));
		addressBooks.add(addressBook);
		addressBook= new AddressBook("Gemma Lane", Gender.Female, dateFormat.parse("20/11/91"));
		addressBooks.add(addressBook);
		return addressBooks;
	}
	
	@Test
	public void testGetMax()throws Exception{
		AddressBookList<AddressBook> addressBooks = sampleData();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/y");
		assertEquals(new AddressBook("Bill McKnight", Gender.Male, dateFormat.parse("16/03/77")),addressBooks.getMaxAge());
	}
	
	@Test
	public void testGetDateDiff()throws Exception{
		AddressBookList<AddressBook> addressBooks = sampleData();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/y");
		AddressBook addressBook2= new AddressBook("Paul Robinson", Gender.Male, dateFormat.parse("15/01/85"));
		AddressBook addressBook1= new AddressBook("Bill McKnight", Gender.Male, dateFormat.parse("16/03/77"));
		int dateDiff = addressBooks.dateDiff(addressBook1, addressBook2);
		assertEquals(2862,dateDiff);
		
	}
}
