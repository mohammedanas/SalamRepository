package com.gumtree.addressbook;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.joda.time.DateTime;
import org.joda.time.Days;

import com.gumtree.addressbook.model.Gender;
import com.gumtree.addressbook.model.AddressBook;

public class AddressBookList<E extends AddressBook> extends ArrayList<E> {
	private Map<Gender,Integer> genderCount = new HashMap<Gender,Integer>();
	public int getMaleCount() {
		return genderCount.get(Gender.Male);
	}
	@Override
	public boolean add(E e) {
		  if( !genderCount.containsKey( e.getGender() ) ){
			  genderCount.put( e.getGender(), 1 );
	        } else { 
	        	genderCount.put( e.getGender(), genderCount.get( e.getGender() ) + 1 );
	        }
		return super.add(e);
	}
	public E getMaxAge() {
		AddressBook maxAge = new AddressBook("",Gender.Female,Calendar.getInstance().getTime());
		for(AddressBook addressBook : this) {
		  if(addressBook.getDob().getTime() <maxAge.getDob().getTime()) {
		    maxAge = addressBook;
		  }
		}
		return (E)maxAge;
	}
	
	public int dateDiff(E addressBook1,E addressBook2){
		return Days.daysBetween(new DateTime(addressBook1.getDob()), new DateTime(addressBook2.getDob())).getDays(); 
	}
	
	
}
