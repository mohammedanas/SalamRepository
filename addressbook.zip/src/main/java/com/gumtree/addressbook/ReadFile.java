package com.gumtree.addressbook;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.gumtree.addressbook.model.AddressBook;
import com.gumtree.addressbook.model.Gender;

public class ReadFile {
private String fileContent;


public ReadFile(String fileContent) {
	this.fileContent= fileContent;
}
public AddressBookList<AddressBook> loadFile() throws IOException{
	BufferedReader fileReader =new BufferedReader(new StringReader(fileContent));
	AddressBookList<AddressBook> addressBooks = new AddressBookList<AddressBook>();
    String line = null;
    while ((line = fileReader.readLine()) != null)
    	addressBooks.add(populateLineContentInAddress(line));
    
    return addressBooks;
}
private AddressBook populateLineContentInAddress(String line){
	String[] elements= line.split(",");
	DateFormat dateFormat = new SimpleDateFormat("dd/MM/y");
	try {
		return new AddressBook(elements[0],Gender.valueOf(elements[1].trim()),dateFormat.parse(elements[2]));
	} catch (ParseException e) {
		throw new IllegalArgumentException(e.getMessage());
	}
}
}
