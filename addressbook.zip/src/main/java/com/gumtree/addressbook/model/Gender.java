package com.gumtree.addressbook.model;

public enum Gender {
	Male,Female
}
